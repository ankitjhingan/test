The problem
===========

The folder here has a binary called `a.out`. When running correctly, it prints out an answer and a verification key.
Out of the box, the binary will not work. You need to figure out what needs to be done to:
(1) First run the binary
(2) Get it print the Answer and Verification key
